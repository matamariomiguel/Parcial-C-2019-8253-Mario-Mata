#include <stdbool.h>
#include <stdint.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "app_time.h"
#include "tick_app.h"
#include "pwm_app.h"
#include "led_app.h"
#include "uart_app.h"
#include "button_app.h"
#include "app_fsm.h"
#include "console_app.h"

/* Pruebas de aceptacion: dejar en 0 para la operacion normal */
#define APP_TEST_TIME_WRAP   0   /* 1 = inyecta el tiempo cerca de UINT32_MAX */
#define APP_TEST_RX_STALL    0   /* 1 = congela main 10 s para desbordar el RX */

int main(void)
{
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
    BOARD_InitDebugConsole();            /* solo deja pines y velocidad de la LPUART */

    uint32_t tickClk = Tick_Init();      /* CTIMER0: tick de 1 ms */
    uint32_t pwmClk = 0U;
    status_t st = Pwm_Init(&pwmClk);     /* CTIMER1: PWM en P3_12 */
    Led_Init();
    Uart_Init();                         /* RX por interrupcion + TX encolado */
    Button_Init();

    uint32_t now = Tick_GetMs();
    Fsm_Init(now);
    Console_Init(now);

    Uart_Printf("\r\nFRDM-MCXA156 listo. CTIMER0=%lu Hz CTIMER1=%lu Hz PWM=%s\r\n",
                (unsigned long)tickClk, (unsigned long)pwmClk,
                (st == kStatus_Success) ? "OK" : "ERROR");
    Uart_Puts("Escriba HELP\r\n");

    uint32_t lastSvc = now;

#if APP_TEST_TIME_WRAP
    bool wrapDone = false;
#endif
#if APP_TEST_RX_STALL
    bool stallDone = false;
#endif

    for (;;)
    {
        now = Tick_GetMs();

#if APP_TEST_TIME_WRAP
        if (!wrapDone && (now > 10000U))
        {
            wrapDone = true;
            Tick_DebugSetMs(0xFFFFFFFFU - 3000U);   /* desborda en ~3 s */
            now = Tick_GetMs();
        }
#endif

#if APP_TEST_RX_STALL
        if (!stallDone && (now > 10000U))
        {
            stallDone = true;
            Uart_Puts("STALL 10 s: pegue ahora 300 caracteres y Enter\r\n");
            uint32_t t0 = now;
            while (Time_Elapsed(Tick_GetMs(), t0) < 10000U)
            {
                Uart_TxService();               /* solo para esta prueba */
            }
            now = Tick_GetMs();
        }
#endif

        if (now != lastSvc)                     /* antirrebote: una vez por ms */
        {
            lastSvc = now;
            Fsm_OnButton(Button_Service(now), now);
        }

        Fsm_Service(now);                       /* rampa AUTO */
        Led_Service(now);                       /* LED de estado */
        Console_Service(now);                   /* parser, respuestas y telemetria */
        Uart_TxService();                       /* vaciar cola TX sin bloquear */
    }
}
