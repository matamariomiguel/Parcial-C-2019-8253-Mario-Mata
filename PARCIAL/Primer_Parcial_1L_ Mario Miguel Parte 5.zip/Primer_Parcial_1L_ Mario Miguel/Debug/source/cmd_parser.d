source/cmd_parser.o source/cmd_parser.d: ../source/cmd_parser.c \
 ../source/cmd_parser.h ../source/uart_app.h
../source/cmd_parser.h:
../source/uart_app.h:
