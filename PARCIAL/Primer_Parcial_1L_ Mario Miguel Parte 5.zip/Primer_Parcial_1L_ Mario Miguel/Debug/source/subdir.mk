################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../source/Primer_Parcial_1L_\ Mario\ Miguel.c \
../source/app_fsm.c \
../source/button_app.c \
../source/cmd_parser.c \
../source/console_app.c \
../source/led_app.c \
../source/pwm_app.c \
../source/semihost_hardfault.c \
../source/tick_app.c \
../source/uart_app.c 

C_DEPS += \
./source/Primer_Parcial_1L_\ Mario\ Miguel.d \
./source/app_fsm.d \
./source/button_app.d \
./source/cmd_parser.d \
./source/console_app.d \
./source/led_app.d \
./source/pwm_app.d \
./source/semihost_hardfault.d \
./source/tick_app.d \
./source/uart_app.d 

OBJS += \
./source/Primer_Parcial_1L_\ Mario\ Miguel.o \
./source/app_fsm.o \
./source/button_app.o \
./source/cmd_parser.o \
./source/console_app.o \
./source/led_app.o \
./source/pwm_app.o \
./source/semihost_hardfault.o \
./source/tick_app.o \
./source/uart_app.o 


# Each subdirectory must supply rules for building sources it contributes
source/Primer_Parcial_1L_\ Mario\ Miguel.o: ../source/Primer_Parcial_1L_\ Mario\ Miguel.c source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DCPU_MCXA156VLL -DCPU_MCXA156VLL_cm33 -DSDK_OS_BAREMETAL -DSDK_DEBUGCONSOLE=1 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -DSERIAL_PORT_TYPE_UART=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\drivers" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\CMSIS" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\CMSIS\m-profile" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\debug_console" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\device" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\device\periph1" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\serial_manager" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\lists" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\str" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\uart" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\debug_console\config" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\board" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\source" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"source/Primer_Parcial_1L_ Mario Miguel.d" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

source/%.o: ../source/%.c source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DCPU_MCXA156VLL -DCPU_MCXA156VLL_cm33 -DSDK_OS_BAREMETAL -DSDK_DEBUGCONSOLE=1 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -DSERIAL_PORT_TYPE_UART=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\drivers" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\CMSIS" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\CMSIS\m-profile" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\debug_console" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\device" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\device\periph1" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\serial_manager" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\lists" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\str" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\uart" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\debug_console\config" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\board" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\source" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source

clean-source:
	-$(RM) ./source/Primer_Parcial_1L_\ Mario\ Miguel.d ./source/Primer_Parcial_1L_\ Mario\ Miguel.o ./source/app_fsm.d ./source/app_fsm.o ./source/button_app.d ./source/button_app.o ./source/cmd_parser.d ./source/cmd_parser.o ./source/console_app.d ./source/console_app.o ./source/led_app.d ./source/led_app.o ./source/pwm_app.d ./source/pwm_app.o ./source/semihost_hardfault.d ./source/semihost_hardfault.o ./source/tick_app.d ./source/tick_app.o ./source/uart_app.d ./source/uart_app.o

.PHONY: clean-source

