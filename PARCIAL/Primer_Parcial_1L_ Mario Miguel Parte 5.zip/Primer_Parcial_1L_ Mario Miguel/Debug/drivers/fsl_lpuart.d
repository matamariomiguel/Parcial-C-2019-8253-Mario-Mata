drivers/fsl_lpuart.o drivers/fsl_lpuart.d: ../drivers/fsl_lpuart.c \
 ../drivers/fsl_lpuart.h ../drivers/fsl_common.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/fsl_device_registers.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/MCXA156.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_ADC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/MCXA156_COMMON.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/core_cm33.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/cmsis_version.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/cmsis_compiler.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/cmsis_gcc.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/system_MCXA156.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/MCXA156_features.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_AOI.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CAN.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CDOG.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CMC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CRC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CTIMER.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_DEBUGMAILBOX.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_DMA.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_EIM.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_EQDC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_ERM.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FLEXIO.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FMC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FMU.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FMUTEST.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FREQME.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_GLIKEY.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_GPIO.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_I3C.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_INPUTMUX.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPCMP.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPDAC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPI2C.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPSPI.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPTMR.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPUART.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_MRCC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_OPAMP.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_OSTIMER.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_PORT.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_PWM.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_SCG.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_SPC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_SYSCON.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_TRDC.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_USB.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_UTICK.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_VBAT.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_WAKETIMER.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_WUU.h \
 C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_WWDT.h \
 ../drivers/fsl_common_arm.h ../drivers/fsl_clock.h \
 ../drivers/fsl_reset.h
../drivers/fsl_lpuart.h:
../drivers/fsl_common.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/fsl_device_registers.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/MCXA156.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_ADC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/MCXA156_COMMON.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/core_cm33.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/cmsis_version.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/cmsis_compiler.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\CMSIS/cmsis_gcc.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/system_MCXA156.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device/MCXA156_features.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_AOI.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CAN.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CDOG.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CMC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CRC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_CTIMER.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_DEBUGMAILBOX.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_DMA.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_EIM.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_EQDC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_ERM.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FLEXIO.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FMC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FMU.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FMUTEST.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_FREQME.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_GLIKEY.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_GPIO.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_I3C.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_INPUTMUX.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPCMP.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPDAC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPI2C.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPSPI.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPTMR.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_LPUART.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_MRCC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_OPAMP.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_OSTIMER.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_PORT.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_PWM.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_SCG.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_SPC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_SYSCON.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_TRDC.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_USB.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_UTICK.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_VBAT.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_WAKETIMER.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_WUU.h:
C:\Users\joelc\Desktop\Primer_Parcial_1L_\ Mario\ Miguel\device\periph1/PERI_WWDT.h:
../drivers/fsl_common_arm.h:
../drivers/fsl_clock.h:
../drivers/fsl_reset.h:
