################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../component/uart/fsl_adapter_lpuart.c 

C_DEPS += \
./component/uart/fsl_adapter_lpuart.d 

OBJS += \
./component/uart/fsl_adapter_lpuart.o 


# Each subdirectory must supply rules for building sources it contributes
component/uart/%.o: ../component/uart/%.c component/uart/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -D__REDLIB__ -DCPU_MCXA156VLL -DCPU_MCXA156VLL_cm33 -DSDK_OS_BAREMETAL -DSDK_DEBUGCONSOLE=1 -DCR_INTEGER_PRINTF -DPRINTF_FLOAT_ENABLE=0 -DSERIAL_PORT_TYPE_UART=1 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\drivers" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\CMSIS" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\CMSIS\m-profile" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\debug_console" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\device" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\device\periph1" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\serial_manager" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\lists" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\str" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\component\uart" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\utilities\debug_console\config" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\board" -I"C:\Users\joelc\Desktop\Primer_Parcial_1L_ Mario Miguel\source" -O0 -fno-common -g3 -gdwarf-4 -Wall -c -ffunction-sections -fdata-sections -fno-builtin -fmerge-constants -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m33 -mfpu=fpv5-sp-d16 -mfloat-abi=hard -mthumb -D__REDLIB__ -fstack-usage -specs=redlib.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-component-2f-uart

clean-component-2f-uart:
	-$(RM) ./component/uart/fsl_adapter_lpuart.d ./component/uart/fsl_adapter_lpuart.o

.PHONY: clean-component-2f-uart

